Roll Rescue test archive.

34 synthetic media items (31 stills, 3 videos) with capture dates from
2017 to 2025, in the shape of a personal media export: nested folders and a
JSON date index at the root. Each still shows its own capture date, so
what Photos files it under can be checked by eye.

Built by spikes/zip-to-photos/tools/make_review_archive.py. Nothing in
here is a real photograph and no personal data is present.
